package main.bg.softuni.contracts;

public interface ContentComparer {

    void compareContent(String actualOutput, String expectedOutput) throws Exception;
}
