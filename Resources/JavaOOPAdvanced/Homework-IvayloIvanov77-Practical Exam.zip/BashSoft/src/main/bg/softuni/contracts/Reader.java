package main.bg.softuni.contracts;

public interface Reader {

    void readCommands() throws Exception;
}
