package main.bg.softuni.contracts;

import java.util.Collection;

public interface SimpleOrderedBag<E extends Comparable<E>> extends Iterable<E> {

//    add, addAll, size and joinWith

    boolean remove(E element);

    int capacity();

    void add(E element);

    void addAll(Collection<E> collection);

    int size();

    String joinWith(String joiner);
}
