import IO.InputReader;

import java.io.IOException;

public class Program {

    public static void main(String[] args) throws IOException, InterruptedException {
//        IO.IOManager.traversDirectory("C:\\Program Files (x86)");

//        Repository.StudentsRepository.initializeData();
//        Repository.StudentsRepository.getStudentsByCourse("Unity");

//        String test1path = "C:\\Users\\Ivaylo\\Documents\\Java Fundamentals\\Java Advanced\\Course Project\\BashSoft\\03. Java-Advanced-BashSoft-Lab\\test2.txt";
//        String test2path = "C:\\Users\\Ivaylo\\Documents\\Java Fundamentals\\Java Advanced\\Course Project\\BashSoft\\03. Java-Advanced-BashSoft-Lab\\test3.txt";
//
//        Judge.Tester.compareContent(test1path, test2path);
//        IO.IOManager.createDirectoryInCurrentFolder("Ivaylo");

        InputReader.readCommands();
    }
}
