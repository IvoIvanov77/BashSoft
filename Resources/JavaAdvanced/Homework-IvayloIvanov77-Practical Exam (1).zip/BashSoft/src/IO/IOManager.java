package IO;

import StaticData.ExceptionMessages;
import StaticData.SessionData;

import java.io.File;
import java.util.LinkedList;

public class IOManager {

    public static void traversDirectory(String path){

        LinkedList<File> subFolders = new LinkedList<>();

        File root = new File(path);

        subFolders.add(root);

        while (!subFolders.isEmpty()){

            File currentFolder = subFolders.removeFirst();

            if(currentFolder.listFiles() != null){
                for(File file : currentFolder.listFiles()){
                    if(file.isDirectory()){
                        subFolders.add(file);
                    }
                }
            }

            System.out.println(currentFolder.toString());
        }

    }

    public static void traversDirectory(int depth){

        LinkedList<File> subFolders = new LinkedList<>();

        String path = SessionData.currentPath;
        int initialIndentation  = path.split("\\\\").length;

        File root = new File(path);

        subFolders.add(root);

        while (!subFolders.isEmpty()){

            File currentFolder = subFolders.removeFirst();
            int currentIndentation  = currentFolder.toString().split("\\\\").length - initialIndentation;

            if(depth - currentIndentation < 0){
                break;
            }
            OutputWriter.writeMessageOnNewLine(currentFolder.toString());

            if(currentFolder.listFiles() != null){
                for(File file : currentFolder.listFiles()){
                    if(file.isDirectory()){
                        subFolders.add(file);
                    }else{
                        int indexOfLastSlash = file.toString().lastIndexOf("\\");
                        for (int i = 0; i < indexOfLastSlash; i++) {
                            OutputWriter.writeMessage("-");
                        }
                        OutputWriter.writeMessageOnNewLine(file.getName());
                    }
                }
            }
        }

    }

    public static void createDirectoryInCurrentFolder(String name){
        String path = getCurrentDirectoryPath() + "\\" + name;
        File file = new File(path);
        file.mkdir();

    }

    public static String getCurrentDirectoryPath(){
        String currentPath = SessionData.currentPath;
        return currentPath;
    }

    public static void changeCurrentDirRelativePath(String relativePath) {
        if (relativePath.equals("..")) {
            String currentPath = SessionData.currentPath;
            int lastSlashIndex = currentPath.lastIndexOf("\\");
            SessionData.currentPath = currentPath.substring(0, lastSlashIndex);
        } else {
            String currentPath = SessionData.currentPath;
            currentPath += "\\" + relativePath;
            changeCurrentDirAbsolute(currentPath);
        }
    }

    public static void changeCurrentDirAbsolute(String absolutePath) {
        File f = new File(absolutePath);
        if (!f.exists()) {
            OutputWriter.displayException(ExceptionMessages.INVALID_PATH);
            return;
        }
        SessionData.currentPath = absolutePath;
    }
}


